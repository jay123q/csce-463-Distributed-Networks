/* DNS.h
 * CPSC 463 Sample Code 
 * by Dmitri Loguinov
 */

#pragma once
#include <Iphlpapi.h>

class DNS {
public:
	void printDNSServer (void);
};