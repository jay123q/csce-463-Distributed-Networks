/* 
 * common.h
 * CPSC 463 Sample Code 
 * by Dmitri Loguinov
 *
 */

// some common .h files every .cpp needs
#pragma once
